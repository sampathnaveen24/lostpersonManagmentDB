from flask import Flask, Response, request, render_template, jsonify
from py2neo import Graph,Node,Relationship
app=Flask(__name__)
url="bolt://localhost:7687"
user_name="neo4j"
password="Sampath@07"
try:
   # Try to connect with neo4j db
   neo=Graph(url,auth=(user_name,password))
except:
    # Exception raised.
    print("Neo4j db connect error")
@app.route('/')
def index():
    return render_template('welcome.html')
@app.route('/register')
def second_page():
    return render_template('register.html')
@app.route('/details')
def third_page():
    return render_template('open.html')
@app.route('/track')
def forth_page():
    return render_template('track.html')
@app.route('/case', methods=['POST'])
def create():
    try:
        # build cypher query from json request to insert data into neo4j db & insert
        data = request.get_json()
        print(data)
        body=""
        for key in data['missingPerson']:
            temp=str(key)+':'+'"'+str(data['missingPerson'][key])+'"'
            if(body!=''):
                body=body+","+temp
            else:
                body=temp
        print(body)
        body1=""
        for key in data['guardianDetails']:
            temp=str(key)+':'+'"'+str(data['guardianDetails'][key])+'"'
            if(body1!=''):
                body1=body1+","+temp
            else:
                body1=temp
        print(body1)
        neo_query="CREATE (p1:Person{"+body+"}) CREATE (p2:Person{"+body1+"}) CREATE (p1)<-[:REPORTED_BY {type:'REPORTED_BY'}]-(p2)"
        print(neo_query)
        result=neo.run(neo_query)
        return {'message': 'New Case Registered', 'Status': 201}
    except Exception as ex:
         response = Response("Insert New Record Error!!",status=500,mimetype='application/json')
         return response 
@app.route('/update_case/<string:uname>', methods=['PATCH'])
def update(uname):
    try:
        data=request.get_json()
        #Search whether node exists for update or not
        final_name= uname.split("|")
        final_name[0]='"'+final_name[0]+'"'
        final_name[1]='"'+final_name[1]+'"'
        search_query="MATCH (m:Movie{title:"+final_name+"}) RETURN m"
        exist=neo.query(search_query).data()
        if(exist==[]):
            return Response("Movie (s) Not found to update", status=200, mimetype='application/json')
        else:
            # Node exists for update & build cypher query to update
            neo_query='match (m:Movie{title:'+final_name+'}) set '
            if "title" in data:
                neo_query=neo_query+ 'm.title='+'"'+data['title']+'"'
            if "rating" in data:
                neo_query=neo_query+ ',m.rating='+data['rating']
            if "description" in data:
                neo_query=neo_query+ ',m.description='+'"'+data['description']+'"'
            neo.run(neo_query)
            return Response('Movie details Updated', status=200, mimetype='application/json')
    except Exception as ex:
        return Response("Update Error!!",status=500,mimetype='application/json')
@app.route('/delete_case/<string:uname>', methods=['DELETE'])
def delete(uname):
  try:
    # Find, Detach and delete nodes
    final_name= uname.split("|")
    final_name[0]='"'+final_name[0]+'"'
    search_query="MATCH (m:Person{elementId1:"+final_name[0]+"}) RETURN m"
    exist=neo.query(search_query).data()
    if(exist==[]):
        return Response("Case (s) Not found to Delete", status=200, mimetype='application/json')
    else:
        neo_query="MATCH (m:Person{elementId1:"+final_name[0]+"}) DETACH DELETE m"
        neo.run(neo_query)
        return {'message':'case Deleted'}
  except Exception as ex:
    return Response("Delete Node Error!!",status=500,mimetype='application/json')    
@app.route('/case/<string:uname>', methods=['GET'])
def getMovie(uname):
    def capitalize_keys(d):
                return {k.capitalize(): v for k, v in d.items()}
    try:
        final_name='"'+uname+'"'
        neo_query="MATCH (missingperson:Person{elementId1:"+final_name+"}) -[relationship:FOUND|REPORTED_BY]-(person:Person) RETURN missingperson,relationship,person"
        #[(d)-[:DIRECTED]->(m)|d.name]AS Director,[(a)-[:ACTED_IN]->(m)|a.name] AS Actors,[(g)-[:IN]->(m)|g.name] AS Genre"
        data= neo.query(neo_query).data()
        result = {
                    "missingpersonInfo": None,
                    "reportedPerson": [],
                    "found": []
                }
        if(data==[]):
            return Response("Record Not found!", status=200, mimetype='application/json')
        else:
            for item in data:
    # Extract missingperson data for missingpersonInfo (from any element)
                if result["missingpersonInfo"] is None:
                    result["missingpersonInfo"] = item["missingperson"]
    
    # Collect persons with relationship type "REPORTED_BY" for reportedPerson
                if item["relationship"]["type"] == "REPORTED_BY":
                    person_info = item["person"]
                    #person_info = {"Name": person_info["name"], **capitalize_keys({k: v for k, v in person_info.items() if k != "name"})}
                    result["reportedPerson"].append(person_info)
    
    # Collect persons with relationship type "FOUND" for found
                if item["relationship"]["type"] == "FOUND":
                    person_info = item["person"]
                    #person_info = {"Name": person_info["name"], **capitalize_keys({k: v for k, v in person_info.items() if k != "name"})}
                    result["found"].append(person_info)
            return result    
    except Exception as ex:
        return  Response("Search Records Error!!",status=500,mimetype='application/json')       
@app.route('/allcases', methods=['GET'])
def searchall():
  try:
    # Get all attributes of movie node.
    result=neo.query("MATCH (p1:Person)<-[:REPORTED_BY]-(p2:Person) RETURN p1.name AS person1_name, p1.missingLocation AS person1_missingLocation, p1.missingDate AS person1_missingDate, p2.name AS person2_name,p1.elementId1 AS person1_id,p2.elementId1 AS person2_id").data()
    if(result==[]):
        return []
    else:
        return result
  except Exception as ex:
    return Response("Search Records Error!!",status=500,mimetype='application/json')

@app.route('/search_case/<string:uname>', methods=['GET'])
def searchall1(uname):
  try:
    final_name='"'+uname+'"'
    print(final_name)
    result=neo.query("MATCH (p1:Person)<-[:REPORTED_BY]-(p2:Person) WHERE p1.name CONTAINS "+ final_name+" RETURN p1.name AS person1_name, p1.missingLocation AS person1_missingLocation, p1.missingDate AS person1_missingDate, p2.name AS person2_name,p1.elementId1 AS person1_id,p2.elementId1 AS person2_id").data()
    print(result)
    if(result==[]):
        return []
    else:
        return result
  except Exception as ex:
    return Response("Search Records Error!!",status=500,mimetype='application/json')

@app.route('/found/<string:uname>', methods=['POST'])
def createf(uname):
    try:
        # build cypher query from json request to insert data into neo4j db & insert
        data = request.get_json()
        final_name= uname.split("|")
        final_name[0]='"'+final_name[0]+'"'
        final_name[1]='"'+final_name[1]+'"'
        print(data)
        print(final_name[0])
        print(final_name[1])
        body=""
        for key in data['missingPerson']:
            temp=str(key)+':'+'"'+str(data['missingPerson'][key])+'"'
            if(body!=''):
                body=body+","+temp
            else:
                body=temp
        print(body)
        neo_query="MATCH (p2:Person{elementId1:"+final_name[0]+"}) MATCH (p3:Person{elementId1:"+final_name[1]+"}) WITH p2,p3 CREATE (p1:Person{"+body+"}) CREATE (p1)-[:FOUND {type:'FOUND'}]->(p2) CREATE (p1)-[:NOTIFIED {type:'NOTIFIED'}]->(p3)"
        print(neo_query)
        result=neo.run(neo_query)
        return {'message': 'New Case Registered', 'Status': 201}
    except Exception as ex:
         response = Response("Insert New Record Error!!",status=500,mimetype='application/json')
         return response 
if __name__ == '__main__':
    app.run(port=5000, debug=True)